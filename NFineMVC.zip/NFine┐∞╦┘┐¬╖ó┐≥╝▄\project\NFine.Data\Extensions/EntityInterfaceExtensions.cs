﻿/*******************************************************************************
 * Copyright © 2016 NFine.Framework 版权所有
 * Author: NFine
 * Description: NFine快速开发平台
 * Website：http://www.nfine.cn
*********************************************************************************/

namespace NFine.Data.Extensions
{
    /// <summary>
    /// 实体接口相关扩展
    /// </summary>
    public static class EntityInterfaceExtensions
    {
        
    }
}
